import java.awt.Graphics;
import javax.swing.JFrame;

public class SortFrameTest {
	public static void main(String args[ ])
	{	    SortFrame  f1 =new SortFrame( );
			f1.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE ); 
	}	 
}	