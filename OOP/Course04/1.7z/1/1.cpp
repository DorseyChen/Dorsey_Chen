#include <graphics.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>
#define I_KEY 0x49
#define J_KEY 0x4A
#define K_KEY 0x4B
#define L_KEY 0x4C

int way(int *p)   // p is up down left right
{
   int k=0;
   for(int i=0;i<4;i++)
     if(p[i]!=0)
       k++;

   if(k==0) return 0;
   else if(k==1)
   {
      if(p[0]==1)      // up
	    return 1;
      else if(p[1]==1) // down
	    return 2;
      else if(p[2]==1) // left
	    return 3;
      else             // right
	    return 4;
   }
   else if(k==2)
   {
      if(p[0]==1 && p[3]==1)      //up & right
	    return 5;
      else if(p[0]==1 && p[2]==1) //up & left
	    return 6;
      else if(p[1]==1 && p[2]==1) //down & left
	    return 7;
      else if(p[1]==1 && p[3]==1) //down & right
	    return 8;
   }
   else
     return 0;
}

int main()
{
	int c[4]={0};
	
    initwindow(900,900);
    setbkcolor(WHITE);
    char f1[9][100]={".\\Backup\\17\\01.bmp",
                     ".\\Backup\\17\\02.bmp",
                     ".\\Backup\\17\\03.bmp",
                     ".\\Backup\\17\\04.bmp",
                     ".\\Backup\\17\\05.bmp",
                     ".\\Backup\\17\\06.bmp",
                     ".\\Backup\\17\\07.bmp",
                     ".\\Backup\\17\\08.bmp",
					 ".\\Backup\\17\\09.bmp"};
    
    char f2[30][100]={".\\Backup\\18\\01.gif",
                      ".\\Backup\\18\\02.gif",
                      ".\\Backup\\18\\03.gif",
                      ".\\Backup\\18\\04.gif",
                      ".\\Backup\\18\\05.gif",
                      ".\\Backup\\18\\06.gif",
                      ".\\Backup\\18\\07.gif",
                      ".\\Backup\\18\\08.gif",
		   			  ".\\Backup\\18\\09.gif",
					  ".\\Backup\\18\\10.gif",
					  ".\\Backup\\18\\11.gif",
					  ".\\Backup\\18\\12.gif",
					  ".\\Backup\\18\\13.gif",
					  ".\\Backup\\18\\14.gif",
					  ".\\Backup\\18\\15.gif",
					  ".\\Backup\\18\\16.gif",
					  ".\\Backup\\18\\17.gif",
					  ".\\Backup\\18\\18.gif",
					  ".\\Backup\\18\\19.gif",
					  ".\\Backup\\18\\20.gif",
					  ".\\Backup\\18\\21.gif",
					  ".\\Backup\\18\\22.gif",
					  ".\\Backup\\18\\23.gif",
					  ".\\Backup\\18\\24.gif",
					  ".\\Backup\\18\\25.gif",
					  ".\\Backup\\18\\26.gif",
					  ".\\Backup\\18\\27.gif",
					  ".\\Backup\\18\\28.gif",
					  ".\\Backup\\18\\29.gif",
					  ".\\Backup\\18\\30.gif"};
    int flag=0,flag2=0,x_path=0,char_path_x=200,char_path_y=500;
    int cur_page=0;
	
	while (1)
    {	
        setvisualpage(cur_page);
        
        cur_page = -cur_page + 1;    
        setactivepage(cur_page);
        
        cleardevice();
        readimagefile(f2[flag],x_path,100,500+x_path,300);
        flag2=(++flag2)%30;
        x_path = (x_path-10+900)%900;
        
        if(GetAsyncKeyState(I_KEY)==0) c[0]=0;
        if(GetAsyncKeyState(K_KEY)==0) c[1]=0;
        if(GetAsyncKeyState(J_KEY)==0) c[2]=0;
        if(GetAsyncKeyState(L_KEY)==0) c[3]=0;
        
        if(GetAsyncKeyState(I_KEY)!=0) char_path_y-=10;
        if(GetAsyncKeyState(K_KEY)!=0) char_path_y+=10;
        if(GetAsyncKeyState(J_KEY)!=0) char_path_x-=10;
        if(GetAsyncKeyState(L_KEY)!=0) char_path_x+=10;
        
        readimagefile(f1[flag],char_path_x,char_path_y,char_path_x+600,char_path_y+381);
        flag=(++flag)%9;
        
        _sleep(50);
    }
    
    
	
    return 0;
}
