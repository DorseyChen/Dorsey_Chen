﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// Multi Form, Struct, Class
namespace MultiForm
{
    struct player1
    {
        public string name;
        public int level;
        public int dead;
    };
       

    public partial class Form1 : Form
    {
        struct player
        {
            public string name;
            public int level;
            public int dead;
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Form2 f2 = new Form2();
            //Form2 f2 = new Form2(textBox1.Text);
            Form2 f2 = new Form2(textBox1.Text, 123);
            f2.Show();
            //f2.ShowDialog();
            //this.Hide();
            //Close();
        }
    }

    public partial class Monster
    {
        int hp;
        int mp;

        public Monster()
        {
        
        }
    }
}
