﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            player1 aa;
        }

        public Form2(string t1)
        {
            InitializeComponent();
            label2.Text = "From1:" + t1;
        }

        public Form2(string t1, int a)
        {
            InitializeComponent();
            label2.Text = "From1:" + t1 + a.ToString();
        }

    }
}
