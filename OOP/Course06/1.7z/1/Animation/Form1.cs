﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Animation
{
    public partial class Form1 : Form
    {
        Image spider;      // image of spider
        float Angle = 0; 　// 擺盪的角度
        float Angle2;
        float Angle_D = 1; // 角度的遞增值
        int spider_y = 100; // 之豬的y軸高度	
        Pen myPen = new Pen(Color.DarkGray, 2); // 汁豬思
        int kukuIndex = 0;
        int girlIndex = 0;
        int x1 = 100, y1 = 400;
        int speed=10;
        int kuku2x, kuku2y;
        Label[] labelList = new Label[5];
        //Bitmap scr = new Bitmap(820, 640);

        public Form1()
        {
            InitializeComponent();
            //this.ClientSize = new Size(1200, 800); // 設定視窗客戶區的寬高
            spider = new Bitmap(Properties.Resources.sp);

            // 在41個按鍵的 Tag 放入 代表的 KeyCode
            // The purpose of the Tag property is for you to use it for any purpose you want. You can safely store anything in there you want.
            // 1.我們可以用Control.Tag屬性來暫存資料(Object)
            // 2.Control.Tag屬性，預設值：C#為 Null。
            // 3.用Control.Tag屬性可以減少變數的命名，充份的利用控制項提供的資源。
            // 4.Tag 屬性的常見用途是儲存與控制項緊密關聯的資料。例如，如果您有一個顯示客戶相關資訊的控制項，您可以將包含客戶訂單記錄的 DataSet 儲存在該控制項的 Tag 屬性中，以便快速存取資料。
            label1.Tag = Keys.Add; label2.Tag = Keys.Subtract; label3.Tag = Keys.Space;
            label4.Tag = Keys.Up; label5.Tag = Keys.Down;
            labelList[0] = label1; labelList[1] = label2; labelList[2] = label3;
            labelList[3] = label4; labelList[4] = label5;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
			int x = this.ClientSize.Width/2;
			int y = this.ClientSize.Height/2;

            Point pt1 = Control.MousePosition;
            pt1 = this.PointToClient(pt1);

            /*
            // Method 1
            e.Graphics.TranslateTransform(x, 0); // 平移畫布的原點
            e.Graphics.RotateTransform(Angle);　// 旋轉畫布

            // 化出汁豬的影像
            e.Graphics.DrawImage(spider, -spider.Width/2, spider_y);            
            // 化出汁豬思
            e.Graphics.DrawLine(myPen, 0, 0, 0, spider_y+32);
            //畫出歐噴哭哭
            e.Graphics.DrawImage(openkuku.Images[kukuIndex], 100, 400);
            */


            // Method 2
            Bitmap scr = new Bitmap(820, 640);  // whole screen image
            Graphics dr1 = Graphics.FromImage(scr);  // 圖層1
            Graphics dr2 = Graphics.FromImage(scr);  // 圖層2
            Graphics dr3 = Graphics.FromImage(scr);

            //平移畫布的原點
            dr1.TranslateTransform(x,0);
            dr3.TranslateTransform(x, 0);
            //旋轉畫布
            dr1.RotateTransform(Angle);
            dr3.RotateTransform(Angle2);
            //化出汁豬的影像
            dr1.DrawImage(spider, -spider.Width/2, spider_y, spider.Width, spider.Height);
			//化出汁豬思
			dr1.DrawLine(myPen,0,0,0,spider_y+32);

            //畫出歐噴哭哭
            x1 -= (x1 - pt1.X) / 20;
            y1 -= (y1 - pt1.Y) / 20;
            kuku2y += speed;

            dr2.DrawImage(openkuku.Images[kukuIndex],x1,y1);
            dr2.DrawImage(girl.Images[girlIndex], pt1.X, pt1.Y);
            dr3.DrawImage(kuku.Images[kukuIndex], 0, kuku2y);

            e.Graphics.DrawImage(scr,0,0);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Angle = Angle + Angle_D;　// 更新擺盪的角度
            if (Angle > 60 || Angle < -60)
                Angle_D = -Angle_D;
            this.Invalidate(); // 重畫
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            kukuIndex++;
            if (kukuIndex == openkuku.Images.Count)
                kukuIndex = 0;
            this.Invalidate();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==(Keys)labelList[0].Tag)
            {
                speed += 5;
            }
            else if (e.KeyCode == (Keys)labelList[1].Tag)
            {
                speed -= 5;
                if (speed < 1)
                    speed = 1;
            }
            else if(e.KeyCode == (Keys)labelList[2].Tag)
            {
                //kuku2x = spider.Width / 2;
                kuku2y = spider_y + 100;
                Angle2 = Angle;
            }
            else if (e.KeyCode == (Keys)labelList[3].Tag)
            {
                spider_y += 10;
            }
            else if (e.KeyCode == (Keys)labelList[4].Tag)
            {
                spider_y -= 10;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (girlIndex == 0)
               girlIndex = 1;
            else
               girlIndex--;
        }
    }
}
