//gr02: demonstrating plotting pixels
#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <dos.h>
#include <conio.h>
#include <time.h>

int main()
{
  srand((unsigned)time(NULL));
  initwindow(1000,1000);
  
  for (int color = 1; color <= 1000; color++)
  {    
    //plot pixels in desired place with given color
    putpixel(rand()%(getmaxx()+1), rand()%(getmaxy()+1), color%16);
    delay(10);
  }
  getch();
  closegraph();
  return 0;
}
