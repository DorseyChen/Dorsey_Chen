//gr01: initializing graphics mode
#include <stdio.h>
#include <graphics.h>
#include <conio.h>
#include <string.h>
int main()
{
  int gd = DETECT, gm = DETECT, xasp, yasp, maxx, maxy;
  char gds[80], gms[80];
  
  //initialize graphics mode
  initwindow(500,1000);
    
  //getdrivename: get the name of graphics driver
  //output the grapihcs driver
  printf("Display card: %s (%d)\n", getdrivername(), gd);
  
  //getmodename: get the name of graphics mode
  //output the graphics mode
  printf("Graphics mode code: %s (%d)\n", getmodename(gm), gm);
  
  //get the current aspect ratio
  getaspectratio(&xasp, &yasp);
  //output the aspect ratio in current graphics mode
  printf("X aspect: %d; y aspect: %d\n", xasp, yasp);
  
  //get the max x and y coordinates in current graphics mode
  maxx = getmaxx();
  maxy = getmaxy();
  //output the max x and y coordinates in current graphics mode
  printf("Max x: %d; max y: %d\n", maxx, maxy);  
  
  //exit graphics mode
  getch();
  closegraph();  
  return 0;
}
