#include <graphics.h>
#include <conio.h>
#include <stdio.h>

int main()
{
	initwindow(1280,1024);
    circle(50,50,50);
    getch();
    closegraph();
}
