//gr05: demonstrating fillings
#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <conio.h>
int main()
{  
  int i;
  //set user-defined fill pattern
  char fill[8] = {0x3c, 0x42, 0x99, 0xa5,
                  0xa5, 0x99, 0x42, 0x3c};  //why?
    
  initwindow(1000,1000);
  
  for (i = 0; i <= 11; i++)
  {
    //use pre-defined pattern; see the slides or TC's help
    setfillstyle(i, i);
    //draw a bar with lefr-top: (100, 10 + i * 30), 
    //right-bottom: (540, 20 + i * 30)
    bar(100, 10 + i * 30, 540, 20 + i * 30);
    getch();
  }
  
  //use user-defined fill pattern
  setfillpattern(fill, i);
  bar(100, 10 + 13 * 30, 540, 41 + 13 * 30);
  getch();
  closegraph();
  return 0;
}
