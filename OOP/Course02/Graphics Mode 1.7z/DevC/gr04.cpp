//gr04: demonstrating plotting polygon and rectangle
#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <conio.h>
int main()
{  
  //define coordinates
  int triangle[8] = {20, 95, 200, 20, 110, 170, 20, 95};
  int pts;
  int i;
    
  initwindow(1000,1000);
    
  //calculate # of points
  //sizeof(triangle) = 8 * sizeof(int)
  //* 2: x and y coordinates
  pts = sizeof(triangle) / (sizeof(int) * 2);  //why?
  //set the color and line style
  setcolor(GREEN);
  //setbkcolor(BLUE);
  setlinestyle(CENTER_LINE, 0, THICK_WIDTH);
  //draw a triangle by drawpoly
  drawpoly(pts, triangle);
  getch();
  
  for (i = 0; i < pts * 2; i += 2)  //update x coordinates
    triangle[i] = triangle[i] + 200;
  setfillstyle(SOLID_FILL, BLUE);
  //draw a triangle by fillpoly  
  fillpoly(pts, triangle);
  getch();
  
  //plot a rectangle outside the triangles
  rectangle(19, 19, 401, 171);
  getch();
  
  closegraph();  //exit
  return 0;
}
