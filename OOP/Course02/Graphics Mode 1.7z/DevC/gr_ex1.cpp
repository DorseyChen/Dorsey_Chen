//gr_ex1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <math.h>
#include <graphics.h>
int main()
{
  int gd = DETECT, gm = DETECT;
  int maxx, maxy;
  char gds[80], gms[80];
  initgraph(&gd, &gm, "c:\\tc\\bgi\\");
  if (graphresult() != grOk)
    exit(1);
  //get the graphics driver and mode
  strcpy(gds, getdrivername());
  strcpy(gms, getmodename(gm));
  //max x and y coordinates
  maxx = getmaxx();
  maxy = getmaxy();
  //A solid while horizontal line with width NORM_WIDTH
  //in the middle of screen
  setlinestyle(SOLID_LINE, 0, NORM_WIDTH);
  line(0, maxy / 2, maxx, maxy / 2);
  //y = -100 * sin(x * pi / 180) + maxy / 2
  for (int i = 0; i <= maxx; i++)
  {
    putpixel(i, (int)(-100 * sin(i * M_PI / 180) + maxy / 2),
      YELLOW);
  }
  //move the CP tp (90, maxy / 2 - 100)
  moveto(90, maxy / 2 - 100);
  lineto(540, maxy / 2 - 100);
  linerel(0, 200);
  lineto(90, maxy / 2 + 100);
  linerel(0, -200);
  getch();
  closegraph();  //exit
  return 0;
}
