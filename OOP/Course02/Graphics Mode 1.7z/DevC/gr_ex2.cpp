//gr_ex2
#include <stdlib.h>
#include <conio.h>
#include <graphics.h>
int main()
{
  int gd = DETECT, gm = DETECT;
  int maxx, maxy;
  int pnts;
  //user-defined pattern
  char upattern[8] = {0x99, 0x18, 0x18, 0xff, 
                      0xff, 0x18, 0x18, 0x99};
  int pentagon[12] = {480,  80, 360, 240, 420, 400, 
                      540, 400, 600, 240, 480,  80};
  initgraph(&gd, &gm, "c:\\tc\\bgi\\");
  if (graphresult() != grOk)
    exit(1);
  //a filled ellipse
  setcolor(YELLOW);
  setlinestyle(SOLID_LINE, 0, NORM_WIDTH);
  setfillstyle(XHATCH_FILL, LIGHTGREEN);
  fillellipse(getmaxx() / 4, getmaxy() / 2, 60, 45);
  //an empty rectangle tangenting to the above ellipse
  setcolor(LIGHTBLUE);
  setlinestyle(SOLID_LINE, 0, NORM_WIDTH);
  rectangle(getmaxx() / 4 - 60, getmaxy() / 2 - 45, 
    getmaxx() / 4 + 60, getmaxy() / 2 + 45);
  //a filled pentagon outside the above figures
  //calculate # of points
  pnts = sizeof(pentagon) / sizeof(int) / 2;
  setcolor(WHITE);
  setlinestyle(DOTTED_LINE, 0, THICK_WIDTH);
  setfillpattern(upattern, CYAN);
  fillpoly(pnts, pentagon);
  getch();
  closegraph();  //exit
  return 0;
}
