//gr06: demonstrating curves
#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <conio.h>
int main()
{
  initwindow(1000,1000);
    
  for (int i = 0; i < 15; i++)
  {
    setcolor(i + 1);  //line color    
    //draw ellipses with centers @ (320, 120)
    ellipse(320, 120, 0, 360, 258 - 12 * i, 90);
    getch();
  }
  getch();
  for (int i = 0; i < 15; i++)
  {
    setcolor(i + 1);  //LINE color!!
    setfillstyle(XHATCH_FILL, 15 - i);  //fill style and color
    //draw ellipses with centers @ (320, 120)
    sector(320, 360, 0, 360, 258 - 12 * i, 90);
    getch();
  }
  getch();
  closegraph();
  return 0;
}
