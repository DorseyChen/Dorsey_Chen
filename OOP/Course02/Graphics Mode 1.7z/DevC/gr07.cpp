//gr07: demonstrating viewport
#include <stdio.h>
#include <graphics.h>
#include <stdlib.h>
#include <conio.h>
int main()
{  
  //define coordinates
  int triangle[8] = {20, 95, 200, 20, 110, 170, 20, 95};
  int strange[8] = {340, 95, 520, 20, 430, 170, 520, 10};
  int pts;

  initwindow(1000,1000);
  
  //draw a triangle by fillpoly
  //calculating number of points
  pts = sizeof(triangle) / (sizeof(int) * 2);
  //set fill type and color
  setfillstyle(INTERLEAVE_FILL, YELLOW);
  fillpoly(pts, triangle);
  getch();
  
  //draw a polygon by fillpoly
  pts = sizeof(strange) / (sizeof(int) * 2);
  setfillstyle(LINE_FILL, WHITE);
  fillpoly(pts, strange);
  getch();
  
  //set viewport. left-top: (0, 240), right-bottom: (319, 479)
  setviewport(0, 240, 319, 479, 0);
  setcolor(YELLOW);  //draw in yellow
  //draw a triangle by drawpoly
  pts = sizeof(triangle) / (sizeof(int) * 2);
  setlinestyle(SOLID_LINE, 0, NORM_WIDTH);
  drawpoly(pts, triangle);
  getch();
  
  //fill the region by floodfill
  setfillstyle(LTSLASH_FILL, YELLOW);
  floodfill(100, 100, YELLOW);  //an inside point
  getch();
  
  clearviewport();  //clear this viewport
  getch();
  
  setlinestyle(SOLID_LINE, 0, THICK_WIDTH);
  setcolor(RED);
  drawpoly(pts, triangle);
  getch();
  
  setfillstyle(WIDE_DOT_FILL, LIGHTGRAY);
  floodfill(0, 0, RED);  //an outside point
  getch();
  
  setcolor(YELLOW);
  //draw a polygon by drawploy
  pts = sizeof(strange) / (sizeof(int) * 2);
  setlinestyle(DOTTED_LINE, 0, THICK_WIDTH);
  drawpoly(pts, strange);
  getch();
  
  closegraph();  //exit
  return 0;
}
