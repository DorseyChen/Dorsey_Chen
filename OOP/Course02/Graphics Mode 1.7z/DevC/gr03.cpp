//gr03: demonstrating on lines
#include <stdio.h>
#include <graphics.h>
#include <conio.h>

int main()
{
	/*
  int gd = DETECT, gm = DETECT, color;
  //gm, gd: use DETECT for automatic detection
  //initialize graphics mode. Be sure to set the path of drivers
  initgraph(&gd, &gm, "c:\\tc\\bgi");
  */
  
  int color;
  initwindow(1000,1000);
  
  if (graphresult() == grOk)  //grOk: ok to draw pictures
  {
    //set background color to green
    setbkcolor(GREEN);
    cleardevice();
    getch();
	
	//set background color to green
    setbkcolor(BLACK);
    cleardevice();
    getch();
	
    //set foreground color to white
    setcolor(RED);
    //solid line with width = 1
    setlinestyle(SOLID_LINE, 0, NORM_WIDTH);
    //draw a line from (200, 150) to (200, 450)
    line(200, 150, 200, 450);
    getch();
    
	//move current position (CP) to (200, 450)
    moveto(200, 450);
    //dotted line with width = 1
    setlinestyle(DOTTED_LINE, 0, NORM_WIDTH);
    //draw a line from CP to (500, 400)
    lineto(500, 450);
    getch();
    
	//centered line with width = 1
    setlinestyle(CENTER_LINE, 0, NORM_WIDTH);
    //draw a line from CP to 300 pixels south from CP
    linerel(0, -300);
    getch();
    
	//userbit line (pattern: "1100 1010 0010 1111")
    //with width = 3
    setlinestyle(USERBIT_LINE, 0xca2f, NORM_WIDTH);  //why 0xca2f?
    linerel(-300, 0);
    getch();
    closegraph();  //exit
  }
  return 0;
}
